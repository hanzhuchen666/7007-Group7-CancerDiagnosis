from django.apps import AppConfig


class UploadImageConfig(AppConfig):
    name = 'upload_image'
