from django.apps import AppConfig


class PersonalCenterConfig(AppConfig):
    name = 'personal_center'
